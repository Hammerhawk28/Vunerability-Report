package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;

import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";

@RestController 

 class ServerController{
	
	@RequestMapping("/hash")
	
	public String CreateHash() {
		String input = "Seth Hamrick";
		MessageDigest digest = null;
		String hashResult = null;
		
		try {
			digest = MessageDigest.getInstance("SHA3-512");
		}
		catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		digest.update(input.getBytes());
		byte [] bytes = digest.digest();
		hashResult = bytesToHex(bytes);
		
		return  "<p>Input: " + input + "<br>Name of the algorithm cipher used: SHA3-512"			//output information on the page

                + "<br>Checksum value: " + hashResult + "</p>";
		}
		
	
	public String bytesToHex(byte[] bytes) {
		String hex = "";
		for (byte val : bytes) {
			hex += String.format("%02X", val);
		}
		return hex;
	}
}
